﻿using System;
using HLIB.MailFormats;

public class Sample
{
    public Sample()
    {

    }

    public void UploadFiles()
    {
        while (true)
        {
            foreach (string sFile in Directory.GetFiles(Program.sMailDrop))
            {
                try
                {
                    FileStream fs = File.Open(sFile, FileMode.Open, FileAccess.ReadWrite);
                    EMLReader reader = new EMLReader(fs);
                    fs.Close();
                    
                    // .... Process EML file here

                    File.Delete(sFile);
                }
                catch (System.IO.IOException err)
                {
                    Debug.WriteLine("File " + sFile + " is currently in use.");
                }
                Thread.Sleep(10);
            }
        }
    }
}
